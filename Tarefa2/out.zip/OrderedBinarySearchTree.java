import java.util.*;


public class OrderedBinarySearchTree extends BinarySearchTree {
    public OrderedBinarySearchTree(int capacity) {
        super(capacity);
    }

    @Override
    public void insert(String val) {
        super.insert(val);
        Arrays.sort(heap, 0, size());
    }

    @Override
    public boolean remove(String val) {
        boolean result = super.remove(val);
        Arrays.sort(heap, 0, size());
        return result;
    }
}
