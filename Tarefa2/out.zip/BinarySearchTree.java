public class BinarySearchTree {
    protected String[] heap;
    private int size;
    private int capacity;

    public BinarySearchTree(int capacity) {
        this.heap = new String[capacity];
        this.size = 0;
        this.capacity = capacity;
    }

    public void insert(String val) {
        if (size == capacity) {
            System.out.println("Heap is full. Cannot insert more elements.");
            return;
        }
        size++;
        int index = size - 1;
        heap[index] = val;
        heapifyUp(index);
    }

    private void heapifyUp(int index) {
        int parent = (index - 1) / 2;
        while (index > 0 && heap[index].compareTo(heap[parent]) < 0) {
            String temp = heap[index];
            heap[index] = heap[parent];
            heap[parent] = temp;
            index = parent;
            parent = (index - 1) / 2;
        }
    }

    public String extractMax() {
        if (size == 0) {
            return null;
        }
        String max = heap[0];
        heap[0] = heap[size - 1];
        size--;
        heapifyDown(0);
        return max;
    }

    private void heapifyDown(int index) {
        int left = 2 * index + 1;
        int right = 2 * index + 2;
        int largest = index;

        if (left < size && heap[left].compareTo(heap[largest]) > 0) {
            largest = left;
        }

        if (right < size && heap[right].compareTo(heap[largest]) > 0) {
            largest = right;
        }

        if (largest != index) {
            String temp = heap[index];
            heap[index] = heap[largest];
            heap[largest] = temp;
            heapifyDown(largest);
        }
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int size() {
        return size;
    }

    public boolean remove(String val) {
        int index = findIndex(val);
        if (index == -1) {
            return false;
        }
        heap[index] = heap[size - 1];
        size--;
        heapifyDown(index);
        return true;
    }

    private int findIndex(String val) {
        for (int i = 0; i < size; i++) {
            if (heap[i].equals(val)) {
                return i;
            }
        }
        return -1;
    }

    public boolean removeByValue(String val) {
        for (int i = 0; i < size; i++) {
            if (heap[i].equals(val)) {
                heap[i] = heap[size - 1];
                size--;
                heapifyDown(i);
                return true;
            }
        }
        return false;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("digraph {\n");

        if (size == 1)
        {
            sb.append("\"" + 0 + " " + heap[0] + "\" ");
            sb.append("}");
            return sb.toString();
        }

        for (int i = 0; i < size; i++) {
            int leftChildIndex = 2 * i + 1;
            int rightChildIndex = 2 * i + 2;

            if (leftChildIndex < size) {
                sb.append("\"" + i + " " + heap[i] + "\" -> \"" + leftChildIndex + " " + heap[leftChildIndex] + "\"\n");
            }
            if (rightChildIndex < size) {
                sb.append("\"" + i + " " + heap[i] + "\" -> \"" + rightChildIndex + " " + heap[rightChildIndex] + "\"\n");
            }
        }

        sb.append("}");
        return sb.toString();
    }
}
